﻿public interface IBrowsable
{
    string BrowseTheNet(string url);
}