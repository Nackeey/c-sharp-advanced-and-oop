﻿using System;
using System.Collections.Generic;
using System.Text;

public class Nation
{
    private List<Bender> benders = new List<Bender>();
    private List<Monument> monuments = new List<Monument>();

    public Nation()
    {
        this.benders = new List<Bender>();
        this.monuments = new List<Monument>();
    }

    public void AddBender(Bender bender) => this.benders.Add(bender);
    public void AddMonument(Monument monument) => this.monuments.Add(monument);

    public override string ToString()
    {
        var sb = new StringBuilder();
        if (benders.Count > 0)
        {
            sb.AppendLine($"Benders:");
            sb.AppendLine(string.Join(Environment.NewLine, benders));
        }
        else
        {
            sb.AppendLine($"Benders: None");
        }

        if (monuments.Count > 0)
        {
            sb.AppendLine($"Monuments:");
            sb.AppendLine(string.Join(Environment.NewLine, monuments));
        }
        else
        {
            sb.AppendLine($"Monuments: None");
        }
        return sb.ToString().Trim();
    }
}

