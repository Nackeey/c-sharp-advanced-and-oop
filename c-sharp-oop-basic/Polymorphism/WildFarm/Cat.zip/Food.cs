﻿public abstract class Food
{
    private int quantity;
    public int Quantity { get; set; }

    public Food(int quantity)
    {
        this.Quantity = this.quantity;
    }
}
