﻿public interface IProduceSound
{
    string SayMoo();
}