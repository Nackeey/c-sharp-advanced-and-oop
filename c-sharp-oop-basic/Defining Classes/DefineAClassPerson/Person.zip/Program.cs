﻿using System;

class Program
{
    static void Main()
    {
        var personOne = new Person();
        personOne.Age = 20;
        personOne.Name = "Pesho";

        var personTwo = new Person();
        personTwo.Age = 18;
        personTwo.Name = "Gosho";

        var personThree = new Person();
        personThree.Age = 43;
        personThree.Name = "Stamat";
    }
}

