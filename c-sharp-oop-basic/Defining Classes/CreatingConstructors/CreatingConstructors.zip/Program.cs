﻿using System;

public class Program
{
    static void Main()
    {
        var person = new Person("Nasko", 31);
        Console.WriteLine($"{person.Name} {person.Age}");

    }
}
