﻿using System;
using System.Collections.Generic;
using System.Text;


public class Cargo
{
    public double weight;
    public string type;

    public Cargo(double weight, string type)
    {
        this.weight = weight;
        this.type = type;
    }
}
