﻿using System;
using System.Collections.Generic;
using System.Text;


public class Engine
{
    public int speed;
    public int power;

    public Engine(int speed, int power)
    {
        this.speed = speed;
        this.power = power;
    }
}

